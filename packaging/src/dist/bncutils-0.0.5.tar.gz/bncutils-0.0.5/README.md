This is an essensial package for Bulls and Cows game (https://github.com/EugeneDlg/bncweb)
This package shares functions and configuration for GUI tkinter version and web version of BnC game.
It includes - bnc_lib.py file which contains some functions which are needeed to function BnC game properly; bnc_config contains a default configuration, normally you should not change it.
good_phrases file is used only in GUI tkinter version, it's not needed for the web version.


